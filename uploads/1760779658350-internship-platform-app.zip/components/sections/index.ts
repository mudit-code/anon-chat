// Re-export helper in case consumers want a single import (optional)
export * from "./hero-section"
export * from "./about-section"
export * from "./nep-guidelines-section"
export * from "./industry-partners-section"
export * from "./career-guidance-section"
